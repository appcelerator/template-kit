This is a basic example with a .gitignore, package.json, and this readme.
