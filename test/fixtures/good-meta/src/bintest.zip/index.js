// this file should be copied into the project
